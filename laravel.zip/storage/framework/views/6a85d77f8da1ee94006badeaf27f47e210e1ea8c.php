<?php $__env->startSection('content'); ?>

            <div class="panel panel-default">
                <div class="panel-heading">
                    Edit and Delete Places
                </div>
                <div class="panel-body">
                    <table class="table table-striped place-table">
                        <thead>
                        <th>ID</th>
                        <th>Company Name</th>
                        <th>UserName</th>
                        <th>Password</th>

                        </thead>


                        <tbody>
                        <?php foreach($allCompanies as $allCompany): ?>
                            <tr>

                                <td class="table-text"><?php echo e($allCompany->id); ?></td>
                                <td class="table-text"><?php echo e($allCompany->company_name); ?></td>
                                <td class="table-text"><?php echo e($allCompany->user_name); ?></td>
                                <td class="table-text"><?php echo e($allCompany->password); ?></td>


                                <td>
                                    <form action="/route/<?php echo e($allCompany->id); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('UPDATE')); ?>


                                        <button type="submit" id="edit-route-<?php echo e($allCompany->id); ?>" class="btn btn-success">
                                            <i class="fa fa-btn fa-edit"></i>Edit
                                        </button>
                                    </form>
                                </td>


                                <td>
                                    <form action="/route/<?php echo e($allCompany->id); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>


                                        <button type="submit" id="delete-route-<?php echo e($allCompany->id); ?>" class="btn btn-danger">
                                            <i class="fa fa-btn fa-trash"></i>Delete
                                        </button>
                                    </form>
                                </td>



                            </tr>
                        <?php endforeach; ?>
                        </tbody>


                    </table>

                </div>
            </div>
        

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>