<?php $__env->startSection('content'); ?>

<div class="col-sm-offset-2">
	<div class="panel panel-default">
		<div class="panel-heading">
			Adding Buses
		</div>
		<div class="panel-body">
			<form action="/admin/bus" method="post">

                <label for="input_weekday">Company Name</label>
                <select name="company_name" class="form-control">
                    <?php foreach($companies as $company): ?>
                        {

                            <option value= <?php echo e($company->company_name); ?> >  <?php echo e($company->company_name); ?>

                            </option>          
                        }
                    <?php endforeach; ?>
                </select>

                <label for="input_boarding">Bus Type</label>
                <select name="bus_type" class="form-control">
                    <?php foreach($bus_types as $bus_type): ?>
                        {

                            <option value= <?php echo e($bus_type->type); ?> >  <?php echo e($bus_type->type); ?></option>          
                        }
                    <?php endforeach; ?>
                </select>

                <label for="input_bus_number">Bus Number</label>
                <input type="number" name="bus_number" id="input_bus_number" class="form-control"></input>

                <label for="input_number_of_rows">Number of rows</label>
                 <input type="number" name="no_of_rows" id="input_number_of_rows" class="form-control">

                <label for="input_number_of_columns">Number of columns</label>
                <input type="number" name="no_of_columns" id="input_schedule" class="form-control">

               
                <button type="submit" class = "btn btn-default">
                    <i class="fa fa-btn fa-plus"></i>Create
                </button>

            </form>

		</div>
	</div>
	<div class="panel panel-default">
		<div class="panel-heading">
			Editing And Deleting Buses
		</div>
		<div class="panel-body">
			<table class="table table-striped place-table">
                        <thead>
                        <th>Company Name</th>
                        <th>Bus Type</th>
                        <th>Bus Number</th>
                        <th>Number of rows</th>
                        <th>Number of columns</th>
                        </thead>


                        <tbody>
                        <?php foreach($buses as $bus): ?>
                            <tr>

                                <td class="table-text"><?php echo e($bus->company_name); ?></td>
                                <td class="table-text"><?php echo e($allCompany->bus_type); ?></td>
                                <td class="table-text"><?php echo e($allCompany->bus_number); ?></td>
                                <td class="table-text"><?php echo e($allCompany->no_of_rows); ?></td>
                                <td class="table-text"><?php echo e($allCompany->no_of_columns); ?></td>


                                <td>
                                    <form action="/route/<?php echo e($allCompany->id); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('UPDATE')); ?>


                                        <button type="submit" id="edit-route-<?php echo e($allCompany->id); ?>" class="btn btn-success">
                                            <i class="fa fa-btn fa-edit"></i>Edit
                                        </button>
                                    </form>
                                </td>


                                <td>
                                    <form action="/route/<?php echo e($allCompany->id); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>


                                        <button type="submit" id="delete-route-<?php echo e($allCompany->id); ?>" class="btn btn-danger">
                                            <i class="fa fa-btn fa-trash"></i>Delete
                                        </button>
                                    </form>
                                </td>



                            </tr>
                        <?php endforeach; ?>
                        </tbody>


                    </table>

		</div>
	</div>


</div
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>