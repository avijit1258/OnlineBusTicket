<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\company;

use App\Http\Requests;

class BusController extends Controller
{


}
