<<!DOCTYPE html>
<html>
<head>
	<title>Welcome Page</title>
	<link rel="stylesheet" type="text/css" href="/assets/css/home.css">
	<script type="text/javascript" src="/assets/js/home.js"></script>

</head>
<body>
	<section class="demo">
  <button class="next">Next</button>
  <button class="prev">Previous</button>
  <div class="container">
    <div style="display: inline-block;">
      <img src="http://placeimg.com/400/200/people"/>
    </div>
    <div>
     <img src="http://placeimg.com/400/200/any"/>
    </div>
    <div>
      <img src="http://placeimg.com/400/200/nature"/>
    </div>
    <div>
      <img src="http://placeimg.com/400/200/architecture"/>
    </div>
    <div>
      <img src="http://placeimg.com/400/200/animals"/>
    </div>
    <div>
      <img src="http://placeimg.com/400/200/people"/>
    </div>
    <div>
      <img src="http://placeimg.com/400/200/tech"/>
    </div>
  </div>
</section>

</body>
</html>